package ex1_first;

public class Ex1_first {
	//main 자동완성 하는법
	//main 적고 ctrl + spacebar
	public static void main(String[] args) {
		//주석 : 프로그램의 소스코드에 개발자의 의견이나 설명을 적어놓는것
		
		// -> 한줄 주석
		
		/*
		 * 여러줄
		 * 주석이
		 * 가능합니다.*/
		
		//sysout적고 ctrl + spacebar
		System.out.println("Hello");
		
		System.out.println("Hi");
		
		System.out.println(100);
		
		//출력함수 안에서 간단한 연산이 가능하다.
		System.out.println(100+50);
		
		//문자열 뒤 숫자는 연결이 된다.
		System.out.println("안녕하세요"+10);
		
		//먼저 계산을 하려면 ()를 쳐야 한다.
		System.out.println("2 + 2 = "+(2+2));
		
		System.out.println("100"+1);
		
		System.out.println(5+10+":"+5+10);
		
		
		
		
		
		
		
		
		
		
		
	}
}
