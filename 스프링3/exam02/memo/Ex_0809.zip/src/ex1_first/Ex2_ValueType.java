package ex1_first;

public class Ex2_ValueType {
	public static void main(String[] args) {
		//자료형 : 데이터를 담는 컵의 크기와 재질 같은 느낌이다.
		//정수형 :	byte	-	1byte	-128 ~ 127
		//			short	-	2byte	-32,768 ~ 32,767
		//			int		-	4byte	-21,4748,3648 ~ 21,4748,3647 (21억)
		//			long	- 	8byte	-900경 ~ 900경
		//문자형	:	char	-	2byte
		//실수형	:	float	-	4byte
		//			double	-	8byte
		//논리형	:	boolean	-	1bit	true(참),false(거짓)
		
		//변수
		//자료형이 데이터를 담기 위한 컵의 재질과 크기라면
		//변수는 데이터를 실제로 담기 위한 컵을 만드는 과정
		
		//변수의 선언
		//비어있는 컵을 만드는 과정
		//자료형 변수명;
		
		//값의 대입
		//만들어져있는 컵에 물(데이터)을 넣는 과정
		//변수명 = 데이터;
		
		//변수의 초기화(Initialize)
		//선언 + 대입
		//자료형 변수명 = 데이터;
		
		//변수명 명명 규칙
		//1. 숫자가 첫글자로 올 수 없다.
		//2. 대소문자를 구별한다. (name, Name)
		//3. _를 제외하고는 특수문자가 들어갈 수 없다.
		//4. 예약어 금지(int,float,char,if,for,switch...)
		//5. 의미있는 이름으로 짓기
		
		
		
		
		
		
		
		
		
		
	}
}
